"""服务模块"""

from .file_service import FileService, file_service

__all__ = [
    "FileService",
    "file_service",
]
